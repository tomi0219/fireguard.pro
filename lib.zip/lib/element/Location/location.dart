class location {
  final double lat;
  final double long;

  location({
    required this.lat,
    required this.long
  });
}

List<location> fireLocationList = [];